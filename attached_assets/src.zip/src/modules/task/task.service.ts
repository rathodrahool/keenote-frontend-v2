import { BadRequestException, Injectable } from '@nestjs/common';
import { CreateTaskDto } from './dto/create-task.dto';
import { UpdateTaskDto } from './dto/update-task.dto';
import { InjectModel } from '@nestjs/mongoose';
import { Task, TaskDocument } from './entities/task.entity';
import { Model } from 'mongoose';
import { ApiResponseHelper } from 'src/shared/response/api-response.helper';
import { ERROR, SUCCESS } from 'src/shared/constants/constant';
import {
  IApiResponse,
  IFindAllQuery,
  IPaginatedResponse,
} from 'src/shared/types/response.type';
import { paginate } from 'src/util/paginate';
import { TaskType, TaskFrequency } from 'src/shared/constants/enum';
import { addDays, addWeeks, addMonths, format } from 'date-fns';

@Injectable()
export class TaskService {
  constructor(
    @InjectModel(Task.name)
    private readonly taskModel: Model<TaskDocument>,
  ) {}

  private calculatePeriodDates(frequency: TaskFrequency, startDate: string) {
    // Parse the date in DD-MM-YYYY format
    const [day, month, year] = startDate.split('-').map(num => parseInt(num));
    const start = new Date(year, month - 1, day); // month is 0-based in Date constructor

    if (isNaN(start.getTime())) {
      throw new BadRequestException('Invalid start date format. Use DD-MM-YYYY');
    }

    let end: Date;

    switch (frequency) {
      case TaskFrequency.DAILY:
        end = addDays(start, 1);
        break;
      case TaskFrequency.WEEKLY:
        end = addWeeks(start, 1);
        break;
      case TaskFrequency.MONTHLY:
        end = addMonths(start, 1);
        break;
      default:
        end = addDays(start, 1);
    }

    return {
      period_start_date: format(start, 'dd-MM-yyyy'),
      period_end_date: format(end, 'dd-MM-yyyy'),
    };
  }

  async create(createTaskDto: CreateTaskDto): Promise<IApiResponse<Task>> {
    const { task_type, target, duration, task_frequency, start_date } = createTaskDto;

    if (task_type === TaskType.YES_NO && !target) {
      throw new BadRequestException('target is required');
    }

    if (task_type === TaskType.TIME_BASED && !duration) {
      throw new BadRequestException('duration is required');
    }

    // Calculate period dates based on frequency
    const periodDates = this.calculatePeriodDates(task_frequency, start_date);

    const task = new this.taskModel({
      ...createTaskDto,
      is_template: true,
      is_completed: false,
      completed_count: 0,
      ...periodDates,
    });

    const result = await task.save();
    return ApiResponseHelper.success(result, SUCCESS.RECORD_ADDED('task'));
  }

  async createTaskInstance(parentTask: TaskDocument): Promise<TaskDocument> {
    const periodDates = this.calculatePeriodDates(
      parentTask.task_frequency,
      parentTask.period_end_date,
    );
  
    const taskData = parentTask.toObject();
    delete taskData._id; 
  
    const taskInstance = new this.taskModel({
      ...taskData,
      parent_task_id: parentTask._id,
      is_template: false,
      is_completed: false,
      completed_count: 0,
      ...periodDates,
    });
  
    return taskInstance.save();
  }

  async updateTaskCompletion(taskId: string, completedTarget: number): Promise<IApiResponse<Task>> {
    const task = await this.taskModel.findById(taskId);
    if (!task) {
      throw new BadRequestException(ERROR.RECORD_NOT_FOUND('task'));
    }

    // Update completion count
    task.completed_count += completedTarget;

    // Check if task is completed based on its type
    let isCompleted = false;
    if (task.task_type === TaskType.YES_NO) {
      isCompleted = task.completed_count >= task.target;
    } else if (task.task_type === TaskType.TIME_BASED) {
      isCompleted = task.completed_count >= task.duration;
    }

    task.is_completed = isCompleted;

    // If task is completed and it's a recurring task, create new instance
    if (isCompleted && task.is_template) {
      await this.createTaskInstance(task);
    }

    const updatedTask = await task.save();
    return ApiResponseHelper.success(updatedTask, SUCCESS.RECORD_UPDATED('task'));
  }

  async findAll(query: IFindAllQuery): Promise<IPaginatedResponse<Task[]>> {
    const tasks = await paginate<Task>(
      this.taskModel,
      query,
      ['name', 'task_frequency', 'task_type', 'category'],
      ['category'],
    );

    return ApiResponseHelper.paginate(
      tasks.results,
      tasks.total,
      tasks.page,
      query.limit,
      SUCCESS.RECORD_FETCHED('category'),
    );
  }

  async findOne(id: string): Promise<IApiResponse<Task>> {
    const task = await this.taskModel.findById(id).populate('category');
    if (!task) {
      throw new BadRequestException(ERROR.RECORD_NOT_FOUND('task'));
    }
    return ApiResponseHelper.success(task, SUCCESS.RECORD_FOUND('task'));
  }

  async update(
    id: string,
    updateTaskDto: UpdateTaskDto,
  ): Promise<IApiResponse<[]>> {
    const task = await this.taskModel.findByIdAndUpdate(id, updateTaskDto, {
      new: true,
    });
    return ApiResponseHelper.success(
      [],
      task ? SUCCESS.RECORD_UPDATED('task') : SUCCESS.RECORD_NOT_FOUND('task'),
    );
  }

  async remove(id: string): Promise<IApiResponse<[]>> {
    const task = await this.taskModel.findById(id);
    if (!task) {
      throw new BadRequestException(ERROR.RECORD_NOT_FOUND('task'));
    }
    await task.softDelete();
    return ApiResponseHelper.success([], SUCCESS.RECORD_DELETED('task'));
  }
}