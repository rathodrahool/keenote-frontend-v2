import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Schema as MongooseSchema } from 'mongoose';
import { Category } from 'src/modules/category/entities/category.entity';
import { Status, TaskFrequency, TaskType } from 'src/shared/constants/enum';
import { ISoftDelete } from 'src/shared/constants/interface';
import { SoftDeleteDefaultFieldsPlugin } from 'src/shared/plugins/soft-delete-default.plugin';

@Schema({
  timestamps: {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
  },
  versionKey: false,
})
export class Task {
  @Prop({ type: String, required: true })
  name: string;

  @Prop({ type: String, enum: TaskType, required: true })
  task_type: TaskType;

  @Prop({ type: String, enum: TaskFrequency, required: true })
  task_frequency: TaskFrequency;

  @Prop({ type: Number, required: false })
  duration: number;

  @Prop({ type: Number, required: false })
  target: number;

  @Prop({ type: String, required: false })
  start_date: string;

  @Prop({ type: String, required: false })
  end_date: string;

  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: 'Category',
    required: true,
  })
  category: Category | MongooseSchema.Types.ObjectId;

  @Prop({ type: String, enum: Status, default: Status.ACTIVE })
  status: Status;

  @Prop({ type: String, required: false })
  parent_task_id: string;

  @Prop({ type: Boolean, default: false })
  is_template: boolean;

  @Prop({ type: String, required: false })
  period_start_date: string;

  @Prop({ type: String, required: false })
  period_end_date: string;

  @Prop({ type: Number, default: 0 })
  completed_count: number;

  @Prop({ type: Boolean, default: false })
  is_completed: boolean;
}

export const TaskSchema = SchemaFactory.createForClass(Task);
TaskSchema.plugin(SoftDeleteDefaultFieldsPlugin);

export type TaskDocument = Task & Document & ISoftDelete & {
  _id: MongooseSchema.Types.ObjectId;
  toObject(): any;
};